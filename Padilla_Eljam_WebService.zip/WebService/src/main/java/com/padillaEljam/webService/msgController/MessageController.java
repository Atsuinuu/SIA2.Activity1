package com.padillaEljam.webService.msgController;

import com.padillaEljam.webService.domain.Message;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MessageController {

    @GetMapping("/RESTapi")
    public Message startMessage(@RequestParam(value = "name", defaultValue = "Example ni Eljam Padilla") String name){

        return new Message(String.format("RESTapi %s :>", name) );
    }

}
