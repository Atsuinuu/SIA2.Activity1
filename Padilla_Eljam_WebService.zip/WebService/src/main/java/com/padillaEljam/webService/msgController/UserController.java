//package com.padillaEljam.webService.msgController;
//
//import org.apache.catalina.User;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//@RequestMapping("/RESTapi")
//public class UserController {
//
//    @GetMapping
//    public User getUser() {
//
//        return User.builder().username()
//                .password()
//                .build();
//
//    }
//}
// hello sir, gin try ko himuon an sa module pero wa gana saak nag eerror po kasi an builder
// ito chada sa may return User.builder()