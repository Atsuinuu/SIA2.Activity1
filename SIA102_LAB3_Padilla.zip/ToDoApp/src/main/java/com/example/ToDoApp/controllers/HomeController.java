package com.example.ToDoApp.controllers;

import org.springframework.stereotype.Controller;
import com.example.ToDoApp.services.TodoItemServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class HomeController {

    @Autowired
    private TodoItemServices todoItemServices;

    @GetMapping("/")
    public ModelAndView index(RedirectAttributes redirectAttributes) {
        ModelAndView modelAndView = new ModelAndView("index");
        try {
            modelAndView.addObject("todoItems", todoItemServices.getAll());
        } catch (Exception e) {
            // Handle the exception and add an error message to the redirect attributes
            redirectAttributes.addFlashAttribute("errorMessage", "Could not load todo items.");
            return new ModelAndView("redirect:/error"); // Redirect to an error page
        }
        return modelAndView;
    }
}
