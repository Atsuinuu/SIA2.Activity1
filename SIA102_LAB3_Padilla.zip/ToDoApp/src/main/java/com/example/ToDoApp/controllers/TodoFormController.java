package com.example.ToDoApp.controllers;

import com.example.ToDoApp.models.User;
import com.example.ToDoApp.models.TodoItem;
import com.example.ToDoApp.services.UserService;
import com.example.ToDoApp.services.TodoItemServices;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

@Controller
public class TodoFormController {

    private final TodoItemServices todoItemServices;
    private final UserService userService;

    @Autowired
    public TodoFormController(TodoItemServices todoItemServices, UserService userService) {
        this.todoItemServices = todoItemServices;
        this.userService = userService;
    }

    @GetMapping("/create-todo")
    public String showCreateForm(TodoItem todoItem, Model model) {
        // Load all users
        List<User> users = userService.findAll();
        model.addAttribute("users", users);
        return "new-todo-item"; // Return the form for creating a new todo item
    }

    @PostMapping("/todo")
    public String createTodoItem(@Valid TodoItem todoItem, @RequestParam String userName, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("users", userService.findAll()); // Load users for the form in case of errors
            return "new-todo-item"; // Return to the creation form if there are validation errors
        }

        // Find user by name or create a new one
        User user = userService.findByName(userName)
                .orElseGet(() -> {
                    User newUser = new User();
                    newUser.setName(userName);
                    return userService.save(newUser);
                });

        // Set the user for the todo item
        todoItem.setUser(user);
        todoItem.setIsComplete(false);
        todoItem.setUpdatedAt(LocalDate.now()); // Set updatedAt when creating a new todo item
        todoItemServices.save(todoItem);
        return "redirect:/"; // Redirect to the home page after saving
    }

    @GetMapping("/delete/{id}")
    public String deleteTodoItem(@PathVariable("id") Long id) {
        todoItemServices.delete(id);
        return "redirect:/"; // Redirect to the home page after deletion
    }

    @PutMapping("/api/todos/{id}")
    @ResponseBody
    public TodoItem updateTodoItem(@PathVariable Long id, @RequestBody TodoItem updatedItem) {
        TodoItem todoItem = todoItemServices.getById(id)
                .orElseThrow(() -> new IllegalArgumentException("TodoItem id: " + id + " not found"));

        todoItem.setIsComplete(updatedItem.getIsComplete());
        todoItem.setUpdatedAt(LocalDate.now()); // Update the 'updatedAt' field
        todoItemServices.save(todoItem);

        return todoItem; // Return the updated item
    }

    @GetMapping("/filter")
    public String filterTodoItems(@RequestParam(required = false) String taskDescription,
                                  @RequestParam(required = false) Long userId,
                                  @RequestParam(required = false) Boolean isComplete,
                                  @RequestParam(required = false) String completionDate,
                                  Model model) {
        LocalDate parsedCompletionDate = null;

        if (completionDate != null && !completionDate.isEmpty()) {
            try {
                parsedCompletionDate = LocalDate.parse(completionDate);
            } catch (DateTimeParseException e) {
                parsedCompletionDate = null; // Handle invalid date parsing
            }
        }

        List<TodoItem> filteredItems = todoItemServices.filterTodoItems(taskDescription, userId, isComplete, parsedCompletionDate);
        model.addAttribute("todoItems", filteredItems);
        model.addAttribute("users", userService.findAll()); // Load users for filtering

        return "index"; // Return to the main index page
    }
}
