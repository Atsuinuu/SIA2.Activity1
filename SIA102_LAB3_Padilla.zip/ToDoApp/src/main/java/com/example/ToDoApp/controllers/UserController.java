package com.example.ToDoApp.controllers;

import com.example.ToDoApp.models.User;
import com.example.ToDoApp.models.TodoItem;
import com.example.ToDoApp.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/add-user")
    public String showAddUserForm(@RequestParam(value = "description", required = false) String description,
                                  @RequestParam(value = "selectedUserId", required = false) Long selectedUserId,
                                  Model model) {
        model.addAttribute("user", new User());
        model.addAttribute("description", description);
        model.addAttribute("selectedUserId", selectedUserId);
        return "add-user";
    }

    @PostMapping("/user")
    public String addUser(@Valid User user, BindingResult result,
                            @RequestParam("description") String description, Model model) {
        if (result.hasErrors()) {
            return "add-user";
        }
        userService.save(user);

        model.addAttribute("users", userService.findAll());
        model.addAttribute("todoItem", new TodoItem());
        model.addAttribute("description", description);
        model.addAttribute("selectedUserId", user.getId());

        return "new-todo-item";
    }
}



