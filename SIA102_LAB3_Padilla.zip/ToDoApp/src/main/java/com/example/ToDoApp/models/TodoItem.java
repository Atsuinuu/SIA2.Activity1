package com.example.ToDoApp.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDate;

@Getter
@Setter
@Entity
@Table(name = "todo_items")
public class TodoItem implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotBlank(message = "Description is required")
    private String description;

    private Boolean isComplete;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user;

    private LocalDate completionDate;

    // New field for updatedAt
    private LocalDate updatedAt;

    // Method to set updatedAt to the current date
    public void setUpdatedAt() {
        this.updatedAt = LocalDate.now();
    }

    @Override
    public String toString() {
        return String.format("TodoItem{id=%d, description='%s', isComplete='%s', user='%s', completionDate='%s', updatedAt='%s'}",
                id, description, isComplete, user != null ? user.getName() : "No user assigned",
                completionDate != null ? completionDate : "No completion date",
                updatedAt != null ? updatedAt : "Not updated yet");
    }
}
