package com.example.ToDoApp.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.ToDoApp.models.User;
import com.example.ToDoApp.models.TodoItem;
import com.example.ToDoApp.repositories.UserRepository;
import com.example.ToDoApp.repositories.TodoItemRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class TodoItemServices {

    @Autowired
    private TodoItemRepository todoItemRepository;

    @Autowired
    private UserRepository userRepository;

    public Optional<TodoItem> findById(Long id) {
        return todoItemRepository.findById(id);
    }

    // Get a TodoItem by its ID
    public Optional<TodoItem> getById(Long id) {
        return todoItemRepository.findById(id);
    }

    // Retrieve all TodoItems
    public Iterable<TodoItem> getAll() {
        return todoItemRepository.findAll();
    }

    // Save a new or updated TodoItem
    public TodoItem save(TodoItem todoItem) {
        return todoItemRepository.save(todoItem);
    }

    // Delete a TodoItem by its ID without renumbering
    public void delete(Long id) {
        Optional<TodoItem> todoItemOptional = todoItemRepository.findById(id);
        if (todoItemOptional.isPresent()) {
            todoItemRepository.delete(todoItemOptional.get());
        }
    }

    // Create a TodoItem for a specific user
    public TodoItem createTodoForUser(Long userId, TodoItem todoItem) {
        Optional<User> user = userRepository.findById(userId);
        if (user.isPresent()) {
            todoItem.setUser(user.get());
            return todoItemRepository.save(todoItem);
        } else {
            throw new IllegalArgumentException("User not found");
        }
    }

    // Find all tasks assigned to a specific user by userId
    public List<TodoItem> findTasksByUser(Long userId) {
        return todoItemRepository.findByUser_Id(userId);
    }

    // Filter TodoItems based on description, user, completion status, and completion date
    public List<TodoItem> filterTodoItems(String taskDescription, Long userId, Boolean isComplete, LocalDate completionDate) {
        List<TodoItem> todoItems = (List<TodoItem>) todoItemRepository.findAll();
        return todoItems.stream()
                .filter(item -> (taskDescription == null || item.getDescription().toLowerCase().contains(taskDescription.toLowerCase()))
                        && (userId == null || (item.getUser() != null && item.getUser().getId().equals(userId)))
                        && (isComplete == null || item.getIsComplete().equals(isComplete))
                        && (completionDate == null || (item.getCompletionDate() != null && item.getCompletionDate().isEqual(completionDate)))
                ).toList();
    }
}
