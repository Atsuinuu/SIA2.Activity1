package com.example.ToDoApp.services;

import com.example.ToDoApp.models.User;
import com.example.ToDoApp.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // Save user to the repository
    public User save(User user) {
        return userRepository.save(user);
    }

    // Find all users
    public List<User> findAll() {
        return userRepository.findAll();
    }

    // Find user by name
    public Optional<User> findByName(String name) {
        return userRepository.findByName(name);
    }

    // Find user by ID
    public Optional<User> findById(Long id) {
        return userRepository.findById(id); // Assuming UserRepository extends JpaRepository
    }
}
